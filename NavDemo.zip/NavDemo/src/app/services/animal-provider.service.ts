import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
	providedIn: 'root'
})
export class AnimalProviderService {


	public isLoading$ : BehaviorSubject<boolean> = new BehaviorSubject(false);
	public animals$ : BehaviorSubject<Array<any>> = new BehaviorSubject([]);

	constructor() { }


	public refresh(){
		this.isLoading$.next(true);
		setTimeout(()=>{
			
			let animals = [{
				id : 1,
				name : "Animal 1",
				description : "<h1>Animal1</h1>",
				image : "https://randomuser.me/api/portraits/men/92.jpg"
			},{
				id : 2,
				name : "Animal 2",
				description : "<h1>Animal2</h1>",
				image : "https://randomuser.me/api/portraits/men/91.jpg"
			},{
				id : 3,
				name : "Animal 3",
				description : "<h1>Animal3</h1>",
				image : "https://randomuser.me/api/portraits/men/90.jpg"
			},{
				id : 4,
				name : "Animal 4",
				description : "<h1>Animal4</h1>",
				image : "https://randomuser.me/api/portraits/men/89.jpg"
			},{
				id : 6,
				name : "Animal 6",
				description : "<h1>Animal6</h1>",
				image : "https://randomuser.me/api/portraits/men/88.jpg"
			},{
				id : 7,
				name : "Animal 7",
				description : "<h1>Animal7</h1>",
				image : "https://randomuser.me/api/portraits/men/87.jpg"
			},{
				id : 8,
				name : "Animal 8",
				description : "<h1>Animal9</h1>",
				image : "https://randomuser.me/api/portraits/men/86.jpg"
			},{
				id : 10,
				name : "Animal 10",
				description : "<h1>Animal10</h1>",
				image : "https://randomuser.me/api/portraits/men/85.jpg"
			}];

			this.animals$.next(animals);
			this.isLoading$.next(false);

		},3000);
	}


	getAnimal(id){
		let animals = this.animals$.value;
		let animal = null;
		animals.forEach((an)=>{
			if(an.id == id){
				animal = an;
			}
		})
		return animal;
	}





}
