import { Component, OnInit } from '@angular/core';
import { AnimalProviderService } from '../services/animal-provider.service';
import { NavController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
	selector: 'app-home',
	templateUrl: 'home.page.html',
	styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {

	constructor(
		public animalService: AnimalProviderService,
		public router : Router
	) { }


	ngOnInit(){
		this.animalService.refresh();
	}

	openAnimal(animalId){

		this.router.navigate(['/animal-view'],{queryParams : {
			animalId : animalId
		}});
	}


}
